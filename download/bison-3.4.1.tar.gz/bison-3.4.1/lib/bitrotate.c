#include <config.h>
#define BITROTATE_INLINE _GL_EXTERN_INLINE
#include "bitrotate.h"
